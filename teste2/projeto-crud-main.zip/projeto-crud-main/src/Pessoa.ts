export interface Pessoa {
  id?: number;
  nome: string;
  idade: number;
  email: string;
}
